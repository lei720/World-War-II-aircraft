//
//  ViewController.m
//  FJDZ
//
//  Created by xupan on 14-7-7.
//  Copyright (c) 2014年 xupan. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    //把背景加载并且显示到VIEW上
    
    bg=[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"bg.png"]];
    bg.frame = CGRectMake(0, 0, 320, 480);
    
    bg1=[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"bg.png"]];
    bg1.frame = CGRectMake(0, -480, 320, 480);
    
    [self.view addSubview:bg];
    
    [self.view addSubview:bg1];
    
    //把飞机加载并显示出来
    
    fj=[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"plane1.png"]];
    
    fj.frame = CGRectMake(120, 350, 77, 96);
    
    [self.view addSubview:fj];
    
    //产生子弹数组
    
    zdArray = [[NSMutableArray alloc] initWithCapacity:0];
    
    [NSTimer scheduledTimerWithTimeInterval:0.01 target:self selector:@selector(loop) userInfo:nil repeats:YES];
    
}
int count=0;
-(void)loop
{
    count++;
    
    
    //对背景进行处理
    CGRect rect= bg.frame;
    
    float y= rect.origin.y;
    
    y++;
    
    rect.origin.y=y;
    
    bg.frame= rect;
    
    bg1.frame = CGRectMake(rect.origin.x, y-480, rect.size.width, rect.size.height);
    
    if (y>480) {
        rect.origin.y=0;
        bg.frame=rect;
        bg1.frame = CGRectMake(rect.origin.x, y-480, rect.size.width, rect.size.height);
    }
    
    //更新飞机的状态
    
    if (count %20 <10)
    {
        
        fj.image=[UIImage imageNamed:@"plane2.png"];
    }
    else
    {
        fj.image=[UIImage imageNamed:@"plane1.png"];
    }
    
    //增加子弹到数组
    
    if (count % 10==0) {
        UIImageView * zdImgView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"zidan.png"]];
        
        CGRect fjrect = fj.frame;
        
        zdImgView.frame = CGRectMake(fjrect.origin.x+fjrect.size.width/2-3.5, fjrect.origin.y-14, 7, 14);
        
        [self.view addSubview:zdImgView];
        
        [zdArray addObject:zdImgView];
    }
    
    //让子弹飞
    
    for (int i=0; i<zdArray.count; i++) {
        UIImageView * imgView = [zdArray objectAtIndex:i];
        CGRect rect= imgView.frame;
        rect.origin.y-=3;
        imgView.frame=rect;
                
        if (rect.origin.y<rect.origin.y) {
            [imgView removeFromSuperview];
        }
    }

}

-(void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
    UITouch *touch=[touches anyObject];
    CGPoint point = [touch locationInView:self.view];
    
    //NSLog(@"touch  x=%f,,y=%f",point.x,point.y);
    
    if (CGRectContainsPoint(fj.frame, point)) {
        fj.center = point;
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
