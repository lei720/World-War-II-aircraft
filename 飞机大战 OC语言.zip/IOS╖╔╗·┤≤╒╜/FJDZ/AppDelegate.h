//
//  AppDelegate.h
//  FJDZ
//
//  Created by xupan on 14-7-7.
//  Copyright (c) 2014年 xupan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
