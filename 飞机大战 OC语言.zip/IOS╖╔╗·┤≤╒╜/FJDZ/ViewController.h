//
//  ViewController.h
//  FJDZ
//
//  Created by xupan on 14-7-7.
//  Copyright (c) 2014年 xupan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    UIImageView * fj;
    UIImageView * bg;
    UIImageView *bg1;
    NSMutableArray * zdArray;
}
@end
